package app.cadence.player.data

import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MusicRepository(private val context: Context) {

    /** Queries MediaStore for MP3 files. Fast: no file is opened, only the index is read. */
    suspend fun scan(minDurationMs: Long): List<Song> = withContext(Dispatchers.IO) {
        val result = ArrayList<Song>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.TRACK,
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND " +
            "${MediaStore.Audio.Media.MIME_TYPE} = ? AND ${MediaStore.Audio.Media.DURATION} >= ?"
        val args = arrayOf("audio/mpeg", minDurationMs.toString())

        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, args,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iDuration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val iTrack = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            while (c.moveToNext()) {
                result += Song(
                    id = c.getLong(iId),
                    title = c.getString(iTitle).clean("Untitled"),
                    artist = c.getString(iArtist).clean("Unknown artist"),
                    album = c.getString(iAlbum).clean("Unknown album"),
                    albumId = c.getLong(iAlbumId),
                    durationMs = c.getLong(iDuration),
                    dateAdded = c.getLong(iAdded),
                    track = c.getInt(iTrack) % 1000, // MediaStore packs disc number in thousands
                )
            }
        }
        result
    }

    private fun String?.clean(fallback: String): String {
        val v = this?.trim()
        return if (v.isNullOrEmpty() || v == MediaStore.UNKNOWN_STRING) fallback else v
    }
}
