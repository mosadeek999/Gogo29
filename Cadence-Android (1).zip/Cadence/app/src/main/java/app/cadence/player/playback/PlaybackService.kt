package app.cadence.player.playback

import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import app.cadence.player.MainActivity
import app.cadence.player.R
import app.cadence.player.data.AppPrefs

/**
 * Foreground playback service. Owns the ExoPlayer and the MediaSession, which gives us the
 * notification, lock-screen controls and Bluetooth/headset media-button handling.
 */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private lateinit var prefs: AppPrefs
    private val handler = Handler(Looper.getMainLooper())

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { sp, key ->
        if (key == AppPrefs.K_UNPLUG) player.setHandleAudioBecomingNoisy(sp.getBoolean(key, true))
    }

    private val saver = object : Runnable {
        override fun run() {
            saveState()
            if (player.isPlaying) handler.postDelayed(this, 5_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = AppPrefs(this)

        val attributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(attributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(prefs.sp.getBoolean(AppPrefs.K_UNPLUG, true))
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(saver)
                if (isPlaying) handler.postDelayed(saver, 5_000L) else saveState()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = saveState()
        })

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, player).setSessionActivity(openApp).build()

        setMediaNotificationProvider(
            DefaultMediaNotificationProvider(this).apply { setSmallIcon(R.drawable.ic_stat_music) }
        )
        prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** Keep playing when the app is swiped away; stop only if nothing is playing. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(saver)
        prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener)
        saveState()
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }

    private fun saveState() {
        val id = player.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        prefs.saveLast(id, player.currentPosition)
    }
}
