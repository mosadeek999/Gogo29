package app.cadence.player.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.cadence.player.MainViewModel
import app.cadence.player.data.ThemeMode
import app.cadence.player.ui.Hairline
import app.cadence.player.ui.ScreenPad
import app.cadence.player.ui.ScreenTitle
import app.cadence.player.ui.SectionHeader
import app.cadence.player.ui.TextAction
import app.cadence.player.ui.muted

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val theme by vm.prefs.theme.collectAsStateWithLifecycle()
    val hideShort by vm.prefs.hideShort.collectAsStateWithLifecycle()
    val pauseOnUnplug by vm.prefs.pauseOnUnplug.collectAsStateWithLifecycle()
    val rememberLast by vm.prefs.remember.collectAsStateWithLifecycle()
    val songs by vm.songs.collectAsStateWithLifecycle()
    val scanning by vm.scanning.collectAsStateWithLifecycle()
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "1.0.0"
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ScreenTitle("Settings", modifier = Modifier.padding(top = 16.dp))

        SectionHeader("Appearance")
        Segmented(
            options = ThemeMode.entries.map { it.label },
            selected = theme.ordinal,
            onSelect = { vm.prefs.setTheme(ThemeMode.entries[it]) },
            modifier = Modifier.padding(horizontal = ScreenPad),
        )

        SectionHeader("Playback")
        SwitchRow("Pause when headphones unplug", "Stops playback if wired or Bluetooth audio disconnects.", pauseOnUnplug) {
            vm.prefs.setPauseOnUnplug(it)
        }
        Hairline(Modifier.padding(horizontal = ScreenPad))
        SwitchRow("Remember last song", "Reopens where you stopped, at the same position.", rememberLast) {
            vm.prefs.setRemember(it)
        }
        Hairline(Modifier.padding(horizontal = ScreenPad))
        SwitchRow("Hide short clips", "Skips audio shorter than 30 seconds, such as voice notes.", hideShort) {
            vm.setHideShort(it)
        }

        SectionHeader("Library")
        Row(Modifier.fillMaxWidth().padding(start = ScreenPad, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("MP3 files on this device", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (scanning) "Scanning\u2026" else "${songs.size} songs found",
                    style = MaterialTheme.typography.bodySmall, color = muted()
                )
            }
            TextAction("Rescan") { vm.rescan() }
        }

        SectionHeader("About")
        Column(Modifier.padding(horizontal = ScreenPad)) {
            Text("Cadence", style = MaterialTheme.typography.headlineSmall)
            Text("Version $version", style = MaterialTheme.typography.bodySmall, color = muted(), modifier = Modifier.padding(top = 2.dp))
            Text(
                "A local music player. It plays MP3 files stored on this device and needs no account, " +
                    "subscription or internet connection.",
                style = MaterialTheme.typography.bodyMedium, color = muted(), modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

@Composable
private fun SwitchRow(title: String, body: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = ScreenPad, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(body, style = MaterialTheme.typography.bodySmall, color = muted())
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(4.dp)
    Row(modifier.fillMaxWidth().clip(shape).border(1.dp, cs.outline, shape)) {
        options.forEachIndexed { index, label ->
            val isSelected = index == selected
            Box(
                Modifier.weight(1f)
                    .background(if (isSelected) cs.onBackground else Color.Transparent)
                    .clickable { onSelect(index) }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label, style = MaterialTheme.typography.labelLarge,
                    color = if (isSelected) cs.background else cs.onBackground
                )
            }
        }
    }
}
