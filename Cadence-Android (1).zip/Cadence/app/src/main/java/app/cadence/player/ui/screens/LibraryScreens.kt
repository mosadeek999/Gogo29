package app.cadence.player.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.cadence.player.MainViewModel
import app.cadence.player.data.Song
import app.cadence.player.data.formatLong
import app.cadence.player.ui.ActionButton
import app.cadence.player.ui.ArtTile
import app.cadence.player.ui.Artwork
import app.cadence.player.ui.BackBar
import app.cadence.player.ui.EmptyState
import app.cadence.player.ui.Hairline
import app.cadence.player.ui.Route
import app.cadence.player.ui.ScreenPad
import app.cadence.player.ui.ScreenTitle
import app.cadence.player.ui.SongRow
import app.cadence.player.ui.SortTabs
import app.cadence.player.ui.muted

@Composable
fun SongsScreen(vm: MainViewModel) {
    val songs by vm.sortedSongs.collectAsStateWithLifecycle()
    val sort by vm.prefs.sort.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        BackBar(onBack = vm::back)
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            item(key = "head") {
                Column {
                    ScreenTitle("Songs", "${songs.size} tracks")
                    SortTabs(sort) { vm.prefs.setSort(it) }
                    Row(Modifier.padding(horizontal = ScreenPad, vertical = 16.dp)) {
                        ActionButton("Shuffle play", filled = true, enabled = songs.isNotEmpty()) { vm.shufflePlay(songs) }
                    }
                }
            }
            itemsIndexed(songs, key = { _, s -> s.id }) { index, song ->
                SongRow(song, vm, onClick = { vm.play(songs, index) })
            }
        }
    }
}

@Composable
fun AlbumsScreen(vm: MainViewModel) {
    val albums by vm.albums.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        BackBar(onBack = vm::back)
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(start = ScreenPad, end = ScreenPad, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                ScreenTitle("Albums", "${albums.size} albums", inset = 0.dp)
            }
            items(albums, key = { it.id }) { album ->
                ArtTile(album.songs.first(), album.title, album.artist) { vm.navigate(Route.Album(album.id)) }
            }
        }
    }
}

@Composable
fun ArtistsScreen(vm: MainViewModel) {
    val artists by vm.artists.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        BackBar(onBack = vm::back)
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            item(key = "head") { ScreenTitle("Artists", "${artists.size} artists") }
            itemsIndexed(artists, key = { _, a -> a.name }) { _, artist ->
                Row(
                    Modifier.fillMaxWidth()
                        .clickable { vm.navigate(Route.Artist(artist.name)) }
                        .padding(horizontal = ScreenPad, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Artwork(artist.songs.first(), Modifier.size(52.dp), px = 160)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(artist.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${artist.songs.size} songs \u00B7 ${artist.albumCount} albums",
                            style = MaterialTheme.typography.bodySmall, color = muted()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AlbumScreen(vm: MainViewModel, id: Long) {
    val albums by vm.albums.collectAsStateWithLifecycle()
    val album = albums.firstOrNull { it.id == id } ?: return
    CollectionScreen(
        vm = vm,
        kicker = "ALBUM",
        title = album.title,
        subtitle = "${album.artist} \u00B7 ${album.songs.size} songs \u00B7 ${formatLong(album.durationMs)}",
        songs = album.songs,
        cover = { Artwork(album.songs.first(), Modifier.fillMaxSize(), px = 600, corner = 2.dp) },
    )
}

@Composable
fun ArtistScreen(vm: MainViewModel, name: String) {
    val artists by vm.artists.collectAsStateWithLifecycle()
    val artist = artists.firstOrNull { it.name == name } ?: return
    CollectionScreen(
        vm = vm,
        kicker = "ARTIST",
        title = artist.name,
        subtitle = "${artist.songs.size} songs \u00B7 ${artist.albumCount} albums",
        songs = artist.songs,
        cover = { Artwork(artist.songs.first(), Modifier.fillMaxSize(), px = 600, corner = 2.dp) },
    )
}

/** Shared layout for album, artist and playlist detail pages. */
@Composable
fun CollectionScreen(
    vm: MainViewModel,
    kicker: String,
    title: String,
    subtitle: String,
    songs: List<Song>,
    cover: @Composable () -> Unit,
    trailing: @Composable RowScope.() -> Unit = {},
    onRemove: ((Song) -> Unit)? = null,
    emptyText: String = "Nothing here yet.",
) {
    Column(Modifier.fillMaxSize()) {
        BackBar(onBack = vm::back, trailing = trailing)
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            item(key = "head") {
                Column(Modifier.padding(horizontal = ScreenPad).padding(bottom = 16.dp)) {
                    androidx.compose.foundation.layout.Box(Modifier.size(200.dp)) { cover() }
                    Text(
                        kicker, style = MaterialTheme.typography.labelSmall, color = muted(),
                        modifier = Modifier.padding(top = 20.dp)
                    )
                    Text(title, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 4.dp))
                    Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = muted(), modifier = Modifier.padding(top = 4.dp))
                    Row(Modifier.padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ActionButton("Play", filled = true, enabled = songs.isNotEmpty()) { vm.play(songs, 0) }
                        ActionButton("Shuffle", filled = false, enabled = songs.isNotEmpty()) { vm.shufflePlay(songs) }
                    }
                }
                Hairline()
            }
            if (songs.isEmpty()) {
                item(key = "empty") { EmptyState("Empty", emptyText) }
            }
            itemsIndexed(songs, key = { _, s -> s.id }) { index, song ->
                SongRow(
                    song, vm,
                    onClick = { vm.play(songs, index) },
                    onRemove = onRemove?.let { remove -> { remove(song) } },
                )
            }
        }
    }
}
