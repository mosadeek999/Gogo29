package app.cadence.player.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import app.cadence.player.MainViewModel
import app.cadence.player.data.formatTime
import app.cadence.player.ui.Artwork
import app.cadence.player.ui.EqualizerBars
import app.cadence.player.ui.Hairline
import app.cadence.player.ui.Ic
import app.cadence.player.ui.muted

@Composable
fun MiniPlayer(vm: MainViewModel, onOpen: () -> Unit) {
    val song by vm.currentSong.collectAsStateWithLifecycle()
    val ui by vm.playerUi.collectAsStateWithLifecycle()
    val position by vm.positionMs.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme
    val current = song ?: return
    val fraction = if (ui.durationMs > 0) (position.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f

    Column(Modifier.fillMaxWidth().background(cs.surfaceVariant)) {
        Box(Modifier.fillMaxWidth().height(2.dp).background(cs.outlineVariant)) {
            Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(cs.primary))
        }
        Row(
            Modifier.fillMaxWidth().height(60.dp).clickable(onClick = onOpen).padding(start = 20.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Artwork(current, Modifier.size(40.dp), px = 96)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(current.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(current.artist, style = MaterialTheme.typography.bodySmall, color = muted(), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = vm::togglePlay) {
                Icon(if (ui.isPlaying) Ic.Pause else Ic.Play, if (ui.isPlaying) "Pause" else "Play", modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = vm::next) { Icon(Ic.Next, "Next", modifier = Modifier.size(26.dp)) }
        }
    }
}

@Composable
fun NowPlayingScreen(vm: MainViewModel, onClose: () -> Unit) {
    val song by vm.currentSong.collectAsStateWithLifecycle()
    val ui by vm.playerUi.collectAsStateWithLifecycle()
    val position by vm.positionMs.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme
    var dragFraction by remember { mutableStateOf<Float?>(null) }

    val duration = ui.durationMs
    val drag = dragFraction
    val fraction = drag ?: if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
    val shownPosition = if (drag != null) (drag * duration).toLong() else position

    Column(
        Modifier.fillMaxSize().background(cs.background).statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 24.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Ic.ChevronDown, "Close") }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                EqualizerBars(ui.isPlaying, cs.primary)
                Spacer(Modifier.width(8.dp))
                Text("NOW PLAYING", style = MaterialTheme.typography.labelSmall, color = muted())
            }
            Spacer(Modifier.size(48.dp))
        }

        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
            val side = minOf(maxWidth, maxHeight)
            val scale by animateFloatAsState(
                targetValue = if (ui.isPlaying) 1f else 0.9f,
                animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessLow),
                label = "artwork-scale"
            )
            Artwork(
                song, Modifier.size(side).graphicsLayer { scaleX = scale; scaleY = scale },
                px = 800, corner = 4.dp
            )
        }

        Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
            Text(song?.title ?: "Nothing playing", style = MaterialTheme.typography.headlineMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(song?.artist ?: "", style = MaterialTheme.typography.bodyLarge, color = muted(), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
        }

        SeekBar(
            fraction = fraction,
            onDrag = { dragFraction = it },
            onDone = { f ->
                vm.seekTo((f * duration).toLong())
                dragFraction = null
            },
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        )
        Row(Modifier.fillMaxWidth()) {
            Text(formatTime(shownPosition), style = MaterialTheme.typography.labelMedium, color = muted())
            Spacer(Modifier.weight(1f))
            Text(formatTime(duration), style = MaterialTheme.typography.labelMedium, color = muted())
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = vm::toggleShuffle) {
                Icon(Ic.Shuffle, "Shuffle", tint = if (ui.shuffle) cs.primary else muted())
            }
            IconButton(onClick = vm::previous, modifier = Modifier.size(56.dp)) {
                Icon(Ic.Previous, "Previous", modifier = Modifier.size(32.dp))
            }
            Box(
                Modifier.size(72.dp).clip(CircleShape).background(cs.primary).clickable(onClick = vm::togglePlay),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (ui.isPlaying) Ic.Pause else Ic.Play, if (ui.isPlaying) "Pause" else "Play",
                    tint = cs.onPrimary, modifier = Modifier.size(38.dp)
                )
            }
            IconButton(onClick = vm::next, modifier = Modifier.size(56.dp)) {
                Icon(Ic.Next, "Next", modifier = Modifier.size(32.dp))
            }
            IconButton(onClick = vm::cycleRepeat) {
                Icon(
                    if (ui.repeatMode == Player.REPEAT_MODE_ONE) Ic.RepeatOne else Ic.Repeat,
                    "Repeat",
                    tint = if (ui.repeatMode == Player.REPEAT_MODE_OFF) muted() else cs.primary
                )
            }
        }
    }
}

/** Thin hairline timeline with a small thumb; tap or drag to seek. */
@Composable
private fun SeekBar(
    fraction: Float,
    onDrag: (Float) -> Unit,
    onDone: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    var width by remember { mutableIntStateOf(1) }
    var dragging by remember { mutableStateOf(false) }
    var last by remember { mutableFloatStateOf(0f) }

    Box(
        modifier
            .height(32.dp)
            .onSizeChanged { width = it.width.coerceAtLeast(1) }
            .pointerInput(Unit) {
                detectTapGestures { offset -> onDone((offset.x / width).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        dragging = true
                        last = (offset.x / width).coerceIn(0f, 1f)
                        onDrag(last)
                    },
                    onDragEnd = { dragging = false; onDone(last) },
                    onDragCancel = { dragging = false; onDone(last) },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        last = (change.position.x / width).coerceIn(0f, 1f)
                        onDrag(last)
                    }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val y = size.height / 2
            val x = size.width * fraction
            drawLine(cs.outline, Offset(0f, y), Offset(size.width, y), strokeWidth = 2.dp.toPx())
            drawLine(cs.primary, Offset(0f, y), Offset(x, y), strokeWidth = 3.dp.toPx())
            drawCircle(cs.primary, radius = (if (dragging) 8.dp else 6.dp).toPx(), center = Offset(x, y))
        }
    }
}
