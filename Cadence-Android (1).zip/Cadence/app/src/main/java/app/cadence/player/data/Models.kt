package app.cadence.player.data

import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val dateAdded: Long,
    val track: Int,
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    val albumArtUri: Uri
        get() = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
}

data class Album(val id: Long, val title: String, val artist: String, val songs: List<Song>) {
    val durationMs: Long get() = songs.sumOf { it.durationMs }
}

data class Artist(val name: String, val songs: List<Song>) {
    val albumCount: Int get() = songs.map { it.albumId }.distinct().size
}

data class SearchResults(
    val songs: List<Song> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList(),
) {
    val isEmpty: Boolean get() = songs.isEmpty() && albums.isEmpty() && artists.isEmpty()
}

fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id.toString())
    .setUri(uri)
    .setMediaMetadata(
        MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(albumArtUri)
            .build()
    )
    .build()

fun sortSongs(list: List<Song>, order: SortOrder): List<Song> = when (order) {
    SortOrder.Title -> list.sortedBy { it.title.lowercase() }
    SortOrder.Artist -> list.sortedWith(
        compareBy<Song>({ it.artist.lowercase() }, { it.album.lowercase() }, { it.track }, { it.title.lowercase() })
    )
    SortOrder.Album -> list.sortedWith(
        compareBy<Song>({ it.album.lowercase() }, { it.track }, { it.title.lowercase() })
    )
    SortOrder.Recent -> list.sortedByDescending { it.dateAdded }
}

fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L)) / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

fun formatLong(ms: Long): String {
    val minutes = ms / 60_000
    return if (minutes >= 60) "${minutes / 60} h ${minutes % 60} min" else "$minutes min"
}
