package app.cadence.player.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import app.cadence.player.data.ThemeMode

// Identity: warm paper and ink with a single ember accent. Serif for voice, sans for utility.
private val Ember = Color(0xFFF0663F)
private val EmberLight = Color(0xFFC9431E)

private val DarkColors = darkColorScheme(
    primary = Ember,
    onPrimary = Color(0xFF14120F),
    secondary = Color(0xFFB9AF9C),
    onSecondary = Color(0xFF14120F),
    background = Color(0xFF14120F),
    onBackground = Color(0xFFEFE8DB),
    surface = Color(0xFF14120F),
    onSurface = Color(0xFFEFE8DB),
    surfaceVariant = Color(0xFF26221D),
    onSurfaceVariant = Color(0xFF9C9486),
    outline = Color(0xFF4A443B),
    outlineVariant = Color(0xFF2B2722),
    surfaceContainerLowest = Color(0xFF100E0C),
    surfaceContainerLow = Color(0xFF191712),
    surfaceContainer = Color(0xFF1F1C17),
    surfaceContainerHigh = Color(0xFF26221D),
    surfaceContainerHighest = Color(0xFF2E2923),
)

private val LightColors = lightColorScheme(
    primary = EmberLight,
    onPrimary = Color(0xFFFAF7F0),
    secondary = Color(0xFF5E564A),
    onSecondary = Color(0xFFFAF7F0),
    background = Color(0xFFF5F0E6),
    onBackground = Color(0xFF1B1814),
    surface = Color(0xFFF5F0E6),
    onSurface = Color(0xFF1B1814),
    surfaceVariant = Color(0xFFE9E2D3),
    onSurfaceVariant = Color(0xFF766E60),
    outline = Color(0xFFBDB29C),
    outlineVariant = Color(0xFFDDD4C2),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF9F5EC),
    surfaceContainer = Color(0xFFEFE9DB),
    surfaceContainerHigh = Color(0xFFE9E2D3),
    surfaceContainerHighest = Color(0xFFE2DAC8),
)

private val Serif = FontFamily.Serif
private val Sans = FontFamily.SansSerif

private val CadenceTypography = Typography(
    displaySmall = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Normal, fontSize = 40.sp, lineHeight = 44.sp, letterSpacing = (-0.8).sp),
    headlineMedium = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Normal, fontSize = 28.sp, lineHeight = 33.sp, letterSpacing = (-0.3).sp),
    headlineSmall = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Normal, fontSize = 22.sp, lineHeight = 28.sp),
    titleLarge = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Normal, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 18.sp, letterSpacing = 0.4.sp),
    labelMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.5.sp),
    labelSmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp, letterSpacing = 1.4.sp),
)

@Composable
fun isDark(mode: ThemeMode): Boolean = when (mode) {
    ThemeMode.System -> isSystemInDarkTheme()
    ThemeMode.Light -> false
    ThemeMode.Dark -> true
}

@Composable
fun CadenceTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = CadenceTypography,
        content = content,
    )
}
