package app.cadence.player.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import app.cadence.player.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Memory-cached album artwork loader. Reads embedded art or the media store thumbnail. */
object ArtworkLoader {
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 8).toInt().coerceAtMost(48 * 1024 * 1024)
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing = java.util.Collections.synchronizedSet(HashSet<String>())

    private fun key(song: Song, px: Int): String =
        (if (song.albumId > 0) "a${song.albumId}" else "s${song.id}") + "@$px"

    fun peek(song: Song, px: Int): Bitmap? = cache.get(key(song, px))

    suspend fun load(context: Context, song: Song, px: Int): Bitmap? = withContext(Dispatchers.IO) {
        val k = key(song, px)
        cache.get(k)?.let { return@withContext it }
        if (k in missing) return@withContext null
        val bitmap = decode(context.applicationContext, song, px)
        if (bitmap != null) cache.put(k, bitmap) else missing.add(k)
        bitmap
    }

    private fun decode(context: Context, song: Song, px: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                return context.contentResolver.loadThumbnail(song.uri, Size(px, px), null)
            } catch (_: Exception) {
                // No artwork for this file; fall through to the embedded-picture path.
            }
        }
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, song.uri)
            retriever.embeddedPicture?.let { decodeSampled(it, px) }
        } catch (_: Exception) {
            null
        } finally {
            retriever.release()
        }
    }

    private fun decodeSampled(data: ByteArray, px: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(data, 0, data.size, options)
    }
}
