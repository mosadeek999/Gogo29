package app.cadence.player.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode(val label: String) { System("System"), Light("Light"), Dark("Dark") }

enum class SortOrder(val label: String) {
    Title("Title"), Artist("Artist"), Album("Album"), Recent("Recent")
}

class AppPrefs(context: Context) {
    val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private val _theme = MutableStateFlow(enumOr(ThemeMode.System, sp.getString(K_THEME, null)))
    val theme: StateFlow<ThemeMode> = _theme.asStateFlow()

    private val _sort = MutableStateFlow(enumOr(SortOrder.Title, sp.getString(K_SORT, null)))
    val sort: StateFlow<SortOrder> = _sort.asStateFlow()

    private val _hideShort = MutableStateFlow(sp.getBoolean(K_HIDE_SHORT, true))
    val hideShort: StateFlow<Boolean> = _hideShort.asStateFlow()

    private val _pauseOnUnplug = MutableStateFlow(sp.getBoolean(K_UNPLUG, true))
    val pauseOnUnplug: StateFlow<Boolean> = _pauseOnUnplug.asStateFlow()

    private val _remember = MutableStateFlow(sp.getBoolean(K_REMEMBER, true))
    val remember: StateFlow<Boolean> = _remember.asStateFlow()

    private val _recent = MutableStateFlow(readRecent())
    val recent: StateFlow<List<Long>> = _recent.asStateFlow()

    fun setTheme(v: ThemeMode) { _theme.value = v; sp.edit().putString(K_THEME, v.name).apply() }
    fun setSort(v: SortOrder) { _sort.value = v; sp.edit().putString(K_SORT, v.name).apply() }
    fun setHideShort(v: Boolean) { _hideShort.value = v; sp.edit().putBoolean(K_HIDE_SHORT, v).apply() }
    fun setPauseOnUnplug(v: Boolean) { _pauseOnUnplug.value = v; sp.edit().putBoolean(K_UNPLUG, v).apply() }
    fun setRemember(v: Boolean) { _remember.value = v; sp.edit().putBoolean(K_REMEMBER, v).apply() }

    fun pushRecent(id: Long) {
        val next = (listOf(id) + _recent.value.filter { it != id }).take(MAX_RECENT)
        _recent.value = next
        sp.edit().putString(K_RECENT, next.joinToString(",")).apply()
    }

    val lastId: Long get() = sp.getLong(K_LAST_ID, -1L)
    val lastPos: Long get() = sp.getLong(K_LAST_POS, 0L)

    fun saveLast(id: Long, position: Long) {
        if (!sp.getBoolean(K_REMEMBER, true)) return
        sp.edit().putLong(K_LAST_ID, id).putLong(K_LAST_POS, position.coerceAtLeast(0L)).apply()
    }

    private fun readRecent(): List<Long> =
        sp.getString(K_RECENT, "").orEmpty().split(",").mapNotNull { it.toLongOrNull() }

    private inline fun <reified E : Enum<E>> enumOr(default: E, name: String?): E =
        enumValues<E>().firstOrNull { it.name == name } ?: default

    companion object {
        const val FILE = "cadence_prefs"
        const val K_THEME = "theme"
        const val K_SORT = "sort"
        const val K_HIDE_SHORT = "hide_short"
        const val K_UNPLUG = "pause_on_unplug"
        const val K_REMEMBER = "remember_position"
        const val K_RECENT = "recent"
        const val K_LAST_ID = "last_id"
        const val K_LAST_POS = "last_pos"
        const val MAX_RECENT = 20
    }
}
