package app.cadence.player.ui

sealed interface Route {
    data object Home : Route
    data object Songs : Route
    data object Albums : Route
    data object Artists : Route
    data object Playlists : Route
    data object Search : Route
    data object Settings : Route
    data class Album(val id: Long) : Route
    data class Artist(val name: String) : Route
    data class Playlist(val id: String) : Route
}
