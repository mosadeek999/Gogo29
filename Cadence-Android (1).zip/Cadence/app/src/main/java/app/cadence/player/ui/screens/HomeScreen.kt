package app.cadence.player.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.cadence.player.MainViewModel
import app.cadence.player.ui.ArtTile
import app.cadence.player.ui.EmptyState
import app.cadence.player.ui.Hairline
import app.cadence.player.ui.Route
import app.cadence.player.ui.ScreenPad
import app.cadence.player.ui.ScreenTitle
import app.cadence.player.ui.SectionHeader
import app.cadence.player.ui.SongRow
import app.cadence.player.ui.ActionButton
import app.cadence.player.ui.muted

@Composable
fun HomeScreen(vm: MainViewModel) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val albums by vm.albums.collectAsStateWithLifecycle()
    val artists by vm.artists.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val recentlyPlayed by vm.recentlyPlayed.collectAsStateWithLifecycle()
    val recentlyAdded by vm.recentlyAdded.collectAsStateWithLifecycle()
    val scanning by vm.scanning.collectAsStateWithLifecycle()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item(key = "title") {
            ScreenTitle(
                "Cadence",
                if (songs.isEmpty()) null else "${songs.size} songs on this device",
                Modifier.padding(top = 16.dp)
            )
        }

        if (songs.isEmpty()) {
            item(key = "empty") {
                if (scanning) {
                    EmptyState("Looking for music\u2026", "Scanning this device for MP3 files.")
                } else {
                    EmptyState(
                        "No MP3 files found",
                        "Copy some music onto this device, then scan again.",
                        action = { ActionButton("Scan again", filled = true) { vm.rescan() } }
                    )
                }
            }
        } else {
            item(key = "index") {
                Column {
                    Hairline()
                    IndexRow("Songs", songs.size) { vm.navigate(Route.Songs) }
                    IndexRow("Albums", albums.size) { vm.navigate(Route.Albums) }
                    IndexRow("Artists", artists.size) { vm.navigate(Route.Artists) }
                    IndexRow("Playlists", playlists.size) { vm.selectTab(Route.Playlists) }
                }
            }

            if (recentlyPlayed.isNotEmpty()) {
                item(key = "recent-played-header") { SectionHeader("Recently played") }
                item(key = "recent-played") {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = ScreenPad),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        itemsIndexed(recentlyPlayed.take(12), key = { _, s -> s.id }) { index, song ->
                            ArtTile(
                                song, song.title, song.artist, Modifier.width(136.dp)
                            ) { vm.play(recentlyPlayed, index) }
                        }
                    }
                }
            }

            if (recentlyAdded.isNotEmpty()) {
                item(key = "recent-added-header") {
                    SectionHeader("Recently added", "All songs") { vm.navigate(Route.Songs) }
                }
                itemsIndexed(recentlyAdded, key = { _, s -> "added-${s.id}" }) { index, song ->
                    SongRow(song, vm, onClick = { vm.play(recentlyAdded, index) })
                }
            }
        }
    }
}

@Composable
private fun IndexRow(label: String, count: Int, onClick: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = ScreenPad, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            Text("$count", style = MaterialTheme.typography.bodyMedium, color = muted())
        }
        Hairline()
    }
}
