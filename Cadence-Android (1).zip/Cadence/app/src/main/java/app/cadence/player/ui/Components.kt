package app.cadence.player.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.cadence.player.MainViewModel
import app.cadence.player.data.Playlist
import app.cadence.player.data.Song
import app.cadence.player.data.SortOrder

val ScreenPad = 20.dp

@Composable
fun muted(): Color = MaterialTheme.colorScheme.onSurfaceVariant

// ---- Artwork ------------------------------------------------------------------------------

private val Tones = listOf(
    Color(0xFF3B4A54), Color(0xFF6B4B3E), Color(0xFF4F5D45),
    Color(0xFF7A6A53), Color(0xFF5A4A63), Color(0xFF2F4F55),
)

@Composable
fun Artwork(song: Song?, modifier: Modifier = Modifier, px: Int = 160, corner: Dp = 2.dp) {
    val context = LocalContext.current
    val bitmap by produceState(
        initialValue = song?.let { ArtworkLoader.peek(it, px) },
        song?.albumId, song?.id, px
    ) {
        value = if (song == null) null else ArtworkLoader.load(context, song, px)
    }
    Box(modifier.clip(RoundedCornerShape(corner))) {
        val bmp = bitmap
        if (bmp != null) {
            val image = remember(bmp) { bmp.asImageBitmap() }
            Image(
                bitmap = image, contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
            )
        } else {
            ArtworkPlaceholder(song)
        }
    }
}

@Composable
private fun ArtworkPlaceholder(song: Song?) {
    val tone = Tones[Math.floorMod((song?.album ?: "").hashCode(), Tones.size)]
    BoxWithConstraints(Modifier.fillMaxSize().background(tone), contentAlignment = Alignment.Center) {
        val letter = (song?.album ?: song?.title ?: "").trim().firstOrNull()?.uppercase() ?: "\u266A"
        val size = with(LocalDensity.current) { (minOf(maxWidth, maxHeight) * 0.42f).toSp() }
        Text(letter, color = Color(0xCCEFE8DB), fontFamily = FontFamily.Serif, fontSize = size)
    }
}

/** 2x2 mosaic of distinct album covers, or a single cover, or a neutral tile when empty. */
@Composable
fun PlaylistArtwork(songs: List<Song>, modifier: Modifier = Modifier, px: Int = 240) {
    val covers = songs.distinctBy { it.albumId }.take(4)
    when {
        covers.isEmpty() -> Box(
            modifier.clip(RoundedCornerShape(2.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) { Icon(Ic.Note, null, tint = muted(), modifier = Modifier.size(28.dp)) }
        covers.size < 4 -> Artwork(covers.first(), modifier, px)
        else -> Column(modifier.clip(RoundedCornerShape(2.dp))) {
            for (r in 0..1) Row(Modifier.weight(1f)) {
                for (c in 0..1) Artwork(covers[r * 2 + c], Modifier.weight(1f).fillMaxSize(), px / 2, 0.dp)
            }
        }
    }
}

// ---- Small pieces -------------------------------------------------------------------------

@Composable
fun Hairline(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant))
}

@Composable
fun EqualizerBars(active: Boolean, color: Color, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "eq")
    val a by transition.animateFloat(0.25f, 1f, infiniteRepeatable(tween(520, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by transition.animateFloat(0.2f, 0.9f, infiniteRepeatable(tween(410, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    val c by transition.animateFloat(0.35f, 1f, infiniteRepeatable(tween(630, easing = LinearEasing), RepeatMode.Reverse), label = "c")
    Canvas(modifier.size(14.dp, 12.dp)) {
        val barWidth = 3.dp.toPx()
        val gap = (size.width - barWidth * 3) / 2
        listOf(a, b, c).forEachIndexed { i, h ->
            val height = size.height * (if (active) h else 0.25f)
            drawRoundRect(
                color, Offset(i * (barWidth + gap), size.height - height),
                Size(barWidth, height), CornerRadius(1.dp.toPx())
            )
        }
    }
}

@Composable
fun BackBar(onBack: () -> Unit, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Ic.Back, "Back") }
        Spacer(Modifier.weight(1f))
        trailing()
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null, modifier: Modifier = Modifier, inset: Dp = ScreenPad) {
    Column(modifier.padding(horizontal = inset).padding(top = 8.dp, bottom = 12.dp)) {
        Text(title, style = MaterialTheme.typography.displaySmall)
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = muted())
    }
}

@Composable
fun SectionHeader(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(start = ScreenPad, end = ScreenPad, top = 28.dp, bottom = 10.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Text(title.uppercase(), style = MaterialTheme.typography.labelSmall, color = muted(), modifier = Modifier.weight(1f))
        if (action != null) {
            Text(
                action, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clickable(onClick = onAction)
            )
        }
    }
}

@Composable
fun TextAction(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Text(
        text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
        modifier = modifier.clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp)
    )
}

@Composable
fun ActionButton(text: String, filled: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(4.dp)
    Box(
        Modifier
            .alpha(if (enabled) 1f else 0.4f)
            .clip(shape)
            .then(if (filled) Modifier.background(cs.primary) else Modifier.border(1.dp, cs.outline, shape))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = if (filled) cs.onPrimary else cs.onBackground)
    }
}

@Composable
fun SortTabs(selected: SortOrder, onSelect: (SortOrder) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.padding(horizontal = ScreenPad), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
        SortOrder.entries.forEach { option ->
            val isSelected = option == selected
            Text(
                option.label,
                style = MaterialTheme.typography.labelLarge,
                color = if (isSelected) cs.onBackground else cs.onSurfaceVariant,
                modifier = Modifier
                    .clickable { onSelect(option) }
                    .drawBehind {
                        if (isSelected) drawLine(cs.primary, Offset(0f, size.height), Offset(size.width, size.height), 2.dp.toPx())
                    }
                    .padding(vertical = 8.dp)
            )
        }
    }
}

@Composable
fun ArtTile(song: Song?, title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick)) {
        Artwork(song, Modifier.fillMaxWidth().aspectRatio(1f), px = 360)
        Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = muted(), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun EmptyState(title: String, body: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Column(modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 48.dp), horizontalAlignment = Alignment.Start) {
        Text(title, style = MaterialTheme.typography.headlineSmall)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = muted(), modifier = Modifier.padding(top = 8.dp, bottom = 20.dp))
        action?.invoke()
    }
}

// ---- Song row -----------------------------------------------------------------------------

@Composable
fun SongRow(
    song: Song,
    vm: MainViewModel,
    onClick: () -> Unit,
    onRemove: (() -> Unit)? = null,
) {
    val ui by vm.playerUi.collectAsStateWithLifecycle()
    val isCurrent = ui.currentId == song.id
    val cs = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf(false) }

    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = ScreenPad, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(song, Modifier.size(52.dp), px = 160)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title, style = MaterialTheme.typography.titleMedium,
                color = if (isCurrent) cs.primary else cs.onBackground,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                "${song.artist} \u00B7 ${song.album}", style = MaterialTheme.typography.bodySmall,
                color = muted(), maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (isCurrent) {
            EqualizerBars(ui.isPlaying, cs.primary, Modifier.padding(horizontal = 8.dp))
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Ic.More, "More", tint = muted()) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Add to playlist") },
                    onClick = { menu = false; vm.requestAddToPlaylist(song) }
                )
                if (onRemove != null) {
                    DropdownMenuItem(
                        text = { Text("Remove from this playlist") },
                        onClick = { menu = false; onRemove() }
                    )
                }
            }
        }
    }
}

// ---- Dialogs ------------------------------------------------------------------------------

@Composable
fun TextInputDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.headlineSmall) },
        text = {
            TextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                placeholder = { Text("Playlist name") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { if (text.isNotBlank()) onConfirm(text) }),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = cs.primary, unfocusedIndicatorColor = cs.outline,
                ),
            )
        },
        confirmButton = { TextAction(confirmLabel) { if (text.isNotBlank()) onConfirm(text) } },
        dismissButton = { TextAction("Cancel", onClick = onDismiss) },
    )
}

@Composable
fun ConfirmDialog(title: String, body: String, confirmLabel: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.headlineSmall) },
        text = { Text(body, style = MaterialTheme.typography.bodyMedium, color = muted()) },
        confirmButton = { TextAction(confirmLabel, onClick = onConfirm) },
        dismissButton = { TextAction("Cancel", onClick = onDismiss) },
    )
}

@Composable
fun AddToPlaylistDialog(vm: MainViewModel, song: Song, onDismiss: () -> Unit) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }

    if (creating) {
        TextInputDialog(
            title = "New playlist", initial = "", confirmLabel = "Create",
            onConfirm = { name ->
                val id = vm.createPlaylist(name)
                vm.addToPlaylist(id, song.id)
                onDismiss()
            },
            onDismiss = { creating = false },
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to playlist", style = MaterialTheme.typography.headlineSmall) },
        text = {
            Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                if (playlists.isEmpty()) {
                    Text("You have no playlists yet.", style = MaterialTheme.typography.bodyMedium, color = muted())
                }
                playlists.forEach { p: Playlist ->
                    val already = song.id in p.songIds
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable(enabled = !already) { vm.addToPlaylist(p.id, song.id); onDismiss() }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${p.songIds.size} songs", style = MaterialTheme.typography.bodySmall, color = muted())
                        }
                        if (already) Text("Added", style = MaterialTheme.typography.labelMedium, color = muted())
                    }
                }
            }
        },
        confirmButton = { TextAction("New playlist") { creating = true } },
        dismissButton = { TextAction("Close", onClick = onDismiss) },
    )
}
