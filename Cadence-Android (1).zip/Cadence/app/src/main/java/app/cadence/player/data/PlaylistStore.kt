package app.cadence.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Playlist(val id: String, val name: String, val songIds: List<Long>)

class PlaylistStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("cadence_playlists", Context.MODE_PRIVATE)
    private val _playlists = MutableStateFlow(load())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    fun create(name: String): String {
        val playlist = Playlist(UUID.randomUUID().toString(), name.trim().ifEmpty { "Untitled" }, emptyList())
        commit(_playlists.value + playlist)
        return playlist.id
    }

    fun rename(id: String, name: String) = edit(id) { it.copy(name = name.trim().ifEmpty { it.name }) }

    fun delete(id: String) = commit(_playlists.value.filter { it.id != id })

    fun add(id: String, songId: Long) = edit(id) {
        if (songId in it.songIds) it else it.copy(songIds = it.songIds + songId)
    }

    fun remove(id: String, songId: Long) = edit(id) { it.copy(songIds = it.songIds.filter { s -> s != songId }) }

    private fun edit(id: String, change: (Playlist) -> Playlist) =
        commit(_playlists.value.map { if (it.id == id) change(it) else it })

    private fun commit(list: List<Playlist>) {
        _playlists.value = list
        val array = JSONArray()
        list.forEach { p ->
            array.put(
                JSONObject().put("id", p.id).put("name", p.name).put("songs", JSONArray(p.songIds))
            )
        }
        sp.edit().putString("data", array.toString()).apply()
    }

    private fun load(): List<Playlist> = try {
        val array = JSONArray(sp.getString("data", "[]"))
        List(array.length()) { i ->
            val o = array.getJSONObject(i)
            val ids = o.getJSONArray("songs")
            Playlist(o.getString("id"), o.getString("name"), List(ids.length()) { n -> ids.getLong(n) })
        }
    } catch (e: Exception) {
        emptyList()
    }
}
