package app.cadence.player

import android.app.Application
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.cadence.player.data.Album
import app.cadence.player.data.AppPrefs
import app.cadence.player.data.Artist
import app.cadence.player.data.MusicRepository
import app.cadence.player.data.PlaylistStore
import app.cadence.player.data.SearchResults
import app.cadence.player.data.Song
import app.cadence.player.data.sortSongs
import app.cadence.player.data.toMediaItem
import app.cadence.player.playback.PlaybackService
import app.cadence.player.ui.Route
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

data class PlayerUi(
    val currentId: Long? = null,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = MusicRepository(app)
    val prefs = AppPrefs(app)
    private val playlistStore = PlaylistStore(app)

    // ---- Library -------------------------------------------------------------------------

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()

    val sortedSongs: StateFlow<List<Song>> =
        combine(songs, prefs.sort) { list, order -> sortSongs(list, order) }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val songById: StateFlow<Map<Long, Song>> =
        songs.map { list -> list.associateBy { it.id } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val albums: StateFlow<List<Album>> =
        songs.map { list ->
            list.groupBy { it.albumId }
                .map { (id, items) ->
                    val sorted = items.sortedWith(compareBy<Song>({ it.track }, { it.title.lowercase() }))
                    Album(id, sorted.first().album, sorted.first().artist, sorted)
                }
                .sortedBy { it.title.lowercase() }
        }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val artists: StateFlow<List<Artist>> =
        songs.map { list ->
            list.groupBy { it.artist }
                .map { (name, items) -> Artist(name, items.sortedBy { it.album.lowercase() }) }
                .sortedBy { it.name.lowercase() }
        }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recentlyPlayed: StateFlow<List<Song>> =
        combine(songById, prefs.recent) { map, ids -> ids.mapNotNull { map[it] } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recentlyAdded: StateFlow<List<Song>> =
        songs.map { list -> list.sortedByDescending { it.dateAdded }.take(10) }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val playlists = playlistStore.playlists

    // ---- Search --------------------------------------------------------------------------

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()
    fun setQuery(value: String) { _query.value = value }

    val results: StateFlow<SearchResults> =
        combine(songs, albums, artists, query) { s, al, ar, q ->
            val terms = q.trim().lowercase().split(' ').filter { it.isNotEmpty() }
            if (terms.isEmpty()) SearchResults()
            else SearchResults(
                songs = s.filter { song ->
                    val hay = "${song.title} ${song.artist} ${song.album}".lowercase()
                    terms.all { hay.contains(it) }
                }.take(100),
                albums = al.filter { a ->
                    val hay = "${a.title} ${a.artist}".lowercase()
                    terms.all { hay.contains(it) }
                }.take(20),
                artists = ar.filter { a ->
                    val hay = a.name.lowercase()
                    terms.all { hay.contains(it) }
                }.take(20),
            )
        }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, SearchResults())

    // ---- Navigation ----------------------------------------------------------------------

    private val _stack = MutableStateFlow<List<Route>>(listOf(Route.Home))
    val stack: StateFlow<List<Route>> = _stack.asStateFlow()

    private val _nowPlayingOpen = MutableStateFlow(false)
    val nowPlayingOpen: StateFlow<Boolean> = _nowPlayingOpen.asStateFlow()

    private val _addTarget = MutableStateFlow<Song?>(null)
    val addTarget: StateFlow<Song?> = _addTarget.asStateFlow()

    fun navigate(route: Route) = _stack.update { it + route }
    fun back() = _stack.update { if (it.size > 1) it.dropLast(1) else it }
    fun selectTab(route: Route) { _stack.value = listOf(route) }
    fun setNowPlaying(open: Boolean) { _nowPlayingOpen.value = open }
    fun requestAddToPlaylist(song: Song?) { _addTarget.value = song }

    // ---- Playback ------------------------------------------------------------------------

    private val _ui = MutableStateFlow(PlayerUi())
    val playerUi: StateFlow<PlayerUi> = _ui.asStateFlow()

    private val _position = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _position.asStateFlow()

    val currentSong: StateFlow<Song?> =
        combine(playerUi, songById) { ui, map -> ui.currentId?.let { map[it] } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private var controller: MediaController? = null
    private var restored = false
    private var lastRecorded: Long? = null

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync()
    }

    private fun sync() {
        val c = controller ?: return
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        val reported = if (c.duration == C.TIME_UNSET) 0L else c.duration
        val fallback = id?.let { songById.value[it]?.durationMs } ?: 0L
        _ui.value = PlayerUi(
            currentId = id,
            isPlaying = c.isPlaying,
            durationMs = if (reported > 0) reported else fallback,
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
        )
        _position.value = c.currentPosition
        if (id != null && id != lastRecorded && c.playWhenReady) {
            lastRecorded = id
            prefs.pushRecent(id)
        }
    }

    fun rescan() {
        if (_scanning.value) return
        viewModelScope.launch {
            _scanning.value = true
            try {
                _songs.value = repository.scan(if (prefs.hideShort.value) 30_000L else 0L)
            } catch (e: Exception) {
                // Permission revoked or MediaStore unavailable: keep the previous list.
            } finally {
                _scanning.value = false
            }
            tryRestore()
        }
    }

    fun setHideShort(value: Boolean) {
        prefs.setHideShort(value)
        rescan()
    }

    /** Re-creates the last queue (paused) so the mini player shows where the user left off. */
    private fun tryRestore() {
        val c = controller ?: return
        if (restored || _songs.value.isEmpty()) return
        restored = true
        if (c.mediaItemCount > 0 || !prefs.remember.value) return
        val lastId = prefs.lastId
        if (lastId < 0) return
        val queue = sortSongs(_songs.value, prefs.sort.value)
        val index = queue.indexOfFirst { it.id == lastId }
        if (index < 0) return
        c.setMediaItems(queue.map { it.toMediaItem() }, index, prefs.lastPos)
        c.prepare()
    }

    fun play(queue: List<Song>, index: Int) {
        val c = controller ?: return
        if (index !in queue.indices) return
        c.setMediaItems(queue.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun shufflePlay(queue: List<Song>) {
        val c = controller ?: return
        if (queue.isEmpty()) return
        c.shuffleModeEnabled = true
        play(queue, Random.nextInt(queue.size))
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_ENDED) c.seekToDefaultPosition()
            c.play()
        }
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPrevious() }
    fun seekTo(ms: Long) { controller?.seekTo(ms); _position.value = ms }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    // ---- Playlists -----------------------------------------------------------------------

    fun createPlaylist(name: String): String = playlistStore.create(name)
    fun renamePlaylist(id: String, name: String) = playlistStore.rename(id, name)
    fun deletePlaylist(id: String) = playlistStore.delete(id)
    fun addToPlaylist(id: String, songId: Long) = playlistStore.add(id, songId)
    fun removeFromPlaylist(id: String, songId: Long) = playlistStore.remove(id, songId)

    init {
        val app = getApplication<Application>()
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                controller = future.get().also { it.addListener(playerListener) }
                sync()
                tryRestore()
            } catch (e: Exception) {
                // Service could not be bound; playback controls stay inert.
            }
        }, ContextCompat.getMainExecutor(app))

        viewModelScope.launch {
            while (true) {
                controller?.let { _position.value = it.currentPosition }
                delay(300)
            }
        }
    }

    override fun onCleared() {
        controller?.removeListener(playerListener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
