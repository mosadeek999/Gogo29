package app.cadence.player.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.cadence.player.MainViewModel
import app.cadence.player.data.formatLong
import app.cadence.player.ui.ConfirmDialog
import app.cadence.player.ui.EmptyState
import app.cadence.player.ui.Ic
import app.cadence.player.ui.PlaylistArtwork
import app.cadence.player.ui.Route
import app.cadence.player.ui.ScreenPad
import app.cadence.player.ui.ScreenTitle
import app.cadence.player.ui.TextAction
import app.cadence.player.ui.TextInputDialog
import app.cadence.player.ui.muted
import app.cadence.player.ui.ActionButton

@Composable
fun PlaylistsScreen(vm: MainViewModel) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val byId by vm.songById.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(end = 8.dp, top = 16.dp), verticalAlignment = Alignment.Bottom) {
            ScreenTitle("Playlists", "${playlists.size} created", Modifier.weight(1f))
            TextAction("New", Modifier.padding(bottom = 12.dp)) { creating = true }
        }
        if (playlists.isEmpty()) {
            EmptyState(
                "No playlists yet",
                "Collect songs into playlists to build your own order.",
                action = { ActionButton("Create playlist", filled = true) { creating = true } }
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = ScreenPad, end = ScreenPad, bottom = 24.dp, top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                items(playlists, key = { it.id }) { playlist ->
                    val songs = playlist.songIds.mapNotNull { byId[it] }
                    Column(Modifier.clickable { vm.navigate(Route.Playlist(playlist.id)) }) {
                        PlaylistArtwork(songs, Modifier.fillMaxWidth().aspectRatio(1f))
                        Text(
                            playlist.name, style = MaterialTheme.typography.titleSmall,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp)
                        )
                        Text(
                            "${songs.size} ${if (songs.size == 1) "song" else "songs"}",
                            style = MaterialTheme.typography.bodySmall, color = muted()
                        )
                    }
                }
            }
        }
    }

    if (creating) {
        TextInputDialog(
            title = "New playlist", initial = "", confirmLabel = "Create",
            onConfirm = { name ->
                val id = vm.createPlaylist(name)
                creating = false
                vm.navigate(Route.Playlist(id))
            },
            onDismiss = { creating = false },
        )
    }
}

@Composable
fun PlaylistScreen(vm: MainViewModel, id: String) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val byId by vm.songById.collectAsStateWithLifecycle()
    var menu by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    val playlist = playlists.firstOrNull { it.id == id }
    if (playlist == null) {
        // Deleted: return to the previous screen.
        androidx.compose.runtime.LaunchedEffect(Unit) { vm.back() }
        return
    }
    val songs = playlist.songIds.mapNotNull { byId[it] }
    val total = songs.sumOf { it.durationMs }

    CollectionScreen(
        vm = vm,
        kicker = "PLAYLIST",
        title = playlist.name,
        subtitle = "${songs.size} ${if (songs.size == 1) "song" else "songs"}" +
            if (songs.isNotEmpty()) " \u00B7 ${formatLong(total)}" else "",
        songs = songs,
        cover = { PlaylistArtwork(songs, Modifier.fillMaxSize(), px = 600) },
        trailing = {
            Box {
                IconButton(onClick = { menu = true }) { Icon(Ic.More, "Playlist options") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; renaming = true })
                    DropdownMenuItem(text = { Text("Delete playlist") }, onClick = { menu = false; deleting = true })
                }
            }
        },
        onRemove = { song -> vm.removeFromPlaylist(playlist.id, song.id) },
        emptyText = "Use the menu on any song to add it here.",
    )

    if (renaming) {
        TextInputDialog(
            title = "Rename playlist", initial = playlist.name, confirmLabel = "Save",
            onConfirm = { vm.renamePlaylist(playlist.id, it); renaming = false },
            onDismiss = { renaming = false },
        )
    }
    if (deleting) {
        ConfirmDialog(
            title = "Delete playlist?",
            body = "\u201C${playlist.name}\u201D will be removed. Your songs stay on the device.",
            confirmLabel = "Delete",
            onConfirm = { deleting = false; vm.deletePlaylist(playlist.id) },
            onDismiss = { deleting = false },
        )
    }
}
