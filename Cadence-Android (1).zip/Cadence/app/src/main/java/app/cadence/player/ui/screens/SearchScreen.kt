package app.cadence.player.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.cadence.player.MainViewModel
import app.cadence.player.ui.Artwork
import app.cadence.player.ui.EmptyState
import app.cadence.player.ui.Ic
import app.cadence.player.ui.Route
import app.cadence.player.ui.ScreenPad
import app.cadence.player.ui.ScreenTitle
import app.cadence.player.ui.SectionHeader
import app.cadence.player.ui.SongRow
import app.cadence.player.ui.muted

@Composable
fun SearchScreen(vm: MainViewModel) {
    val query by vm.query.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Search", modifier = Modifier.padding(top = 16.dp))
        TextField(
            value = query,
            onValueChange = vm::setQuery,
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = ScreenPad - 16.dp),
            placeholder = { Text("Title, artist or album") },
            leadingIcon = { Icon(Ic.Search, null, tint = muted()) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { vm.setQuery("") }) { Icon(Ic.Close, "Clear", tint = muted()) }
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = cs.primary, unfocusedIndicatorColor = cs.outline,
            ),
        )

        when {
            query.isBlank() -> EmptyState("Find anything", "Search across every title, artist and album on this device.")
            results.isEmpty -> EmptyState("No matches", "Nothing found for \u201C${query.trim()}\u201D.")
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                if (results.songs.isNotEmpty()) {
                    item(key = "songs-header") { SectionHeader("Songs") }
                    itemsIndexed(results.songs, key = { _, s -> "song-${s.id}" }) { index, song ->
                        SongRow(song, vm, onClick = { vm.play(results.songs, index) })
                    }
                }
                if (results.albums.isNotEmpty()) {
                    item(key = "albums-header") { SectionHeader("Albums") }
                    itemsIndexed(results.albums, key = { _, a -> "album-${a.id}" }) { _, album ->
                        Row(
                            Modifier.fillMaxWidth().clickable { vm.navigate(Route.Album(album.id)) }
                                .padding(horizontal = ScreenPad, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Artwork(album.songs.first(), Modifier.size(52.dp))
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(album.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(album.artist, style = MaterialTheme.typography.bodySmall, color = muted(), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
                if (results.artists.isNotEmpty()) {
                    item(key = "artists-header") { SectionHeader("Artists") }
                    itemsIndexed(results.artists, key = { _, a -> "artist-${a.name}" }) { _, artist ->
                        Row(
                            Modifier.fillMaxWidth().clickable { vm.navigate(Route.Artist(artist.name)) }
                                .padding(horizontal = ScreenPad, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Artwork(artist.songs.first(), Modifier.size(52.dp))
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(artist.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${artist.songs.size} songs", style = MaterialTheme.typography.bodySmall, color = muted())
                            }
                        }
                    }
                }
            }
        }
    }
}
