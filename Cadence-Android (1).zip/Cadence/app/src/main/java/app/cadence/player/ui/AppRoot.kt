package app.cadence.player.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.cadence.player.MainViewModel
import app.cadence.player.ui.screens.AlbumScreen
import app.cadence.player.ui.screens.AlbumsScreen
import app.cadence.player.ui.screens.ArtistScreen
import app.cadence.player.ui.screens.ArtistsScreen
import app.cadence.player.ui.screens.HomeScreen
import app.cadence.player.ui.screens.MiniPlayer
import app.cadence.player.ui.screens.NowPlayingScreen
import app.cadence.player.ui.screens.PlaylistScreen
import app.cadence.player.ui.screens.PlaylistsScreen
import app.cadence.player.ui.screens.SearchScreen
import app.cadence.player.ui.screens.SettingsScreen
import app.cadence.player.ui.screens.SongsScreen

private val Tabs = listOf(
    "Library" to Route.Home,
    "Playlists" to Route.Playlists,
    "Search" to Route.Search,
    "Settings" to Route.Settings,
)

@Composable
fun AppRoot(vm: MainViewModel) {
    val context = LocalContext.current
    val audioPermission =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasAudioPermission() =
        ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(hasAudioPermission()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioPermission()
    }
    fun requestPermissions() {
        val list = buildList {
            add(audioPermission)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        launcher.launch(list.toTypedArray())
    }

    LaunchedEffect(Unit) { if (!granted) requestPermissions() }
    LaunchedEffect(granted) { if (granted) vm.rescan() }
    LifecycleEventEffect(Lifecycle.Event.ON_START) {
        granted = hasAudioPermission()
        if (granted) vm.rescan()
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background, contentColor = MaterialTheme.colorScheme.onBackground) {
        if (!granted) {
            PermissionScreen(
                onGrant = ::requestPermissions,
                onOpenSettings = {
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                    )
                }
            )
        } else {
            MainContent(vm)
        }
    }
}

@Composable
private fun MainContent(vm: MainViewModel) {
    val stack by vm.stack.collectAsStateWithLifecycle()
    val nowPlaying by vm.nowPlayingOpen.collectAsStateWithLifecycle()
    val addTarget by vm.addTarget.collectAsStateWithLifecycle()

    BackHandler(enabled = nowPlaying) { vm.setNowPlaying(false) }
    BackHandler(enabled = !nowPlaying && stack.size > 1) { vm.back() }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth().statusBarsPadding()) {
                Crossfade(targetState = stack.last(), animationSpec = tween(150), label = "route") { route ->
                    RouteContent(route, vm)
                }
            }
            MiniPlayer(vm) { vm.setNowPlaying(true) }
            TabBar(selected = stack.first(), onSelect = vm::selectTab)
        }

        AnimatedVisibility(
            visible = nowPlaying,
            enter = slideInVertically(tween(280)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(240)) { it } + fadeOut(tween(200)),
        ) {
            NowPlayingScreen(vm) { vm.setNowPlaying(false) }
        }
    }

    addTarget?.let { song -> AddToPlaylistDialog(vm, song) { vm.requestAddToPlaylist(null) } }
}

@Composable
private fun RouteContent(route: Route, vm: MainViewModel) {
    when (route) {
        Route.Home -> HomeScreen(vm)
        Route.Songs -> SongsScreen(vm)
        Route.Albums -> AlbumsScreen(vm)
        Route.Artists -> ArtistsScreen(vm)
        Route.Playlists -> PlaylistsScreen(vm)
        Route.Search -> SearchScreen(vm)
        Route.Settings -> SettingsScreen(vm)
        is Route.Album -> AlbumScreen(vm, route.id)
        is Route.Artist -> ArtistScreen(vm, route.name)
        is Route.Playlist -> PlaylistScreen(vm, route.id)
    }
}

@Composable
private fun TabBar(selected: Route, onSelect: (Route) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().background(cs.background)) {
        Hairline()
        Row(Modifier.fillMaxWidth().navigationBarsPadding().height(52.dp)) {
            Tabs.forEach { (label, route) ->
                val isSelected = route == selected
                Column(
                    Modifier.weight(1f).fillMaxSize().clickable { onSelect(route) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                ) {
                    Box(
                        Modifier.width(16.dp).height(2.dp)
                            .background(if (isSelected) cs.primary else androidx.compose.ui.graphics.Color.Transparent)
                    )
                    Text(
                        label, style = MaterialTheme.typography.labelLarge,
                        color = if (isSelected) cs.onBackground else cs.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit, onOpenSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(32.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        Text("Cadence", style = MaterialTheme.typography.displaySmall)
        Text(
            "To play your music, Cadence needs permission to read audio files on this device. " +
                "Nothing leaves your phone.",
            style = MaterialTheme.typography.bodyLarge, color = muted(),
            modifier = Modifier.padding(top = 12.dp, bottom = 28.dp)
        )
        Row {
            ActionButton("Allow access", filled = true, onClick = onGrant)
            TextAction("Open settings", Modifier.padding(start = 8.dp), onClick = onOpenSettings)
        }
    }
}
